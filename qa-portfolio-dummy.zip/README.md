# 👩‍💻 QA Engineer Portfolio - [Nama Kamu]

Selamat datang di portofolio saya sebagai QA Engineer (Manual & Automation).  
Repo ini berisi contoh **Test Case, Bug Report, Automation Script, Postman Collection, dan Test Report**.

---

## 📌 Profil Singkat
Saya seorang QA Engineer dengan pengalaman dalam Manual & Automation Testing, terbiasa dengan Agile/Scrum,  
dan berfokus pada peningkatan kualitas produk melalui pengujian menyeluruh serta implementasi automation test.

---

## 🛠️ Skills & Tools
**Manual Testing**
- Test Case, Test Plan, Test Scenario  
- Regression, UAT, Smoke Testing  
- Dokumentasi di Confluence / Word  
- Bug Reporting (Jira, Trello)  

**Automation Testing**
- Playwright, Selenium, Cypress  
- API Testing (Postman, Newman)  
- Performance Testing (JMeter, k6)  
- CI/CD (Jenkins, GitHub Actions)  

---

## 📊 Proyek
### 1. E-commerce Website Testing
- **Manual**: 150+ test case (Login, Cart, Checkout, Payment).  
- **Automation**: Playwright test untuk login & checkout.  
- **Tools**: Jira, Playwright, Postman.  
- **Output**: Coverage 90%, regression time -40%.  

👉 [Test Case](./manual-testing/test-cases.xlsx) | [Automation Script](./automation-testing/playwright-tests/sample.test.ts)

---

### 2. Mobile Banking App Testing
- **Manual**: SIT & UAT, validasi API dengan Postman.  
- **Automation**: Regression test dengan Appium.  
- **Tools**: Appium, Postman, GitLab CI.  
- **Output**: Bug production turun 25%.  

👉 [Bug Report](./manual-testing/bug-reports-sample.pdf) | [Test Report](./automation-testing/reports/allure-report.png)

---

## 📑 Contoh Hasil Pekerjaan
- 📄 [Test Case Sample](./manual-testing/test-cases.xlsx)  
- 🐞 [Bug Report Sample](./manual-testing/bug-reports-sample.pdf)  
- 🤖 [Automation Script](./automation-testing/playwright-tests/sample.test.ts)  
- 📊 [Test Execution Report](./automation-testing/reports/allure-report.png)  
- 🌐 [Postman Collection](./automation-testing/postman-collections/api-testing.json)

---

## 🎓 Sertifikasi
- ISTQB Foundation Level  
- Postman API Fundamentals  
- Playwright Automation with TypeScript (Udemy)  

---

## 📞 Kontak
- ✉️ Email: kamu@email.com  
- 💻 GitHub: [github.com/username](https://github.com/username)  
- 🔗 LinkedIn: [linkedin.com/in/username](https://linkedin.com/in/username)  
